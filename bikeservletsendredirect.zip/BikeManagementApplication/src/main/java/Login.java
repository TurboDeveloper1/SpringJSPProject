import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Login extends HttpServlet{
	String username = "Admin";
	String password = "1234";
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Get Method");
	}
	
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		System.out.println("Using Post Method");
		String user = req.getParameter("user");
		String pass = req.getParameter("pass");
		PrintWriter p1 = resp.getWriter();
		
		if(user.equals(username)) {
			if(pass.equals(password)) {
				Cookie c1 = new Cookie("user", user);
				Cookie c2 = new Cookie("writer", "DISHANT");
				req.setAttribute("d", "DISHANT");
				req.setAttribute("a", "ANUJ");
				p1.print("<h1> Welcome "+user+"</h1>");
//				RequestDispatcher rq = req.getRequestDispatcher("Dashboard");
//				rq.forward(req, resp);
				resp.addCookie(c1);
				resp.addCookie(c2);
				resp.sendRedirect("Dashboard");
				
//				cookie, session, servletconfig, servletcontext
			}
			else {
				p1.print("<h1> Your password is wrong, go back and loghhin again</h1>");
			}
		}else {
			p1.print("<h1>There is no user with id "+user+", go back and login again</h1>");
		}
	}
}
