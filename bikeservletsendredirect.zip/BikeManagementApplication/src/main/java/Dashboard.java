import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Dashboard extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Using Get");
		String user="";
		String writer="";
		for(Cookie c : req.getCookies()) {
			if(c.getName().equals("user")) {
				user=c.getValue();
			}
			else if(c.getName().equals("writer"))
			{
				writer=c.getValue();
			}
		}
		
		
		PrintWriter p1 = resp.getWriter();
		p1.print("<h1> Welcome User " +  user + "</h1>");
		p1.print("<h1> Page made by " + writer + "</h1>");

	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Using Post");
		String user="";
		String writer="";
		for(Cookie c : req.getCookies()) {
			if(c.getName().equals("user")) {
				user=c.getValue();
			}
			else if(c.getName().equals("writer"))
			{
				writer=c.getValue();
			}
		}
		
		
		PrintWriter p1 = resp.getWriter();
		p1.print("<h1> Welcome User " +  user + "</h1>");
		p1.print("<h1> Page made by " + writer + "</h1>");
	}
}
